// Chia-Hua Lu
import javax.swing.JFrame;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import javax.swing.*;
public class CS429GUIGradeCalc extends JFrame {

	/* CUSTOMISING VARIABLES */
	private boolean debug = false;
	private String HomeworkWeight = "0.15";
	private String LabWeight = "0.35";
	private String MidtermsWeight = "0.30";
	private String FinalExamWeight = "0.20";
	private double Course_Eval_Bonus_on_Final = 1;
	/* End of variables Section */

	private JPanel mainPanel,weightPanel, HWPanel, ExamPanel, ExamPanelLower, ExamSubPanel1, ExamSubPanel2, LabPanel, FinalsPanel, selectorsPanel, displayPanel, buttonPanel, gradeCutoffPanel;
	private JLabel labelLabs, labelHW, labelExam, labelFinalExam, labelResult, labelCourseEval, skip, labelPrecision;
	private JTextField fieldLabs, fieldHW, fieldExam, fieldFinalExam, fieldExamWeight, fieldFinalWeight, fieldHWWeight, fieldLabWeight, fieldPrecision;
	private JButton buttonSubmit, fractionConverter, buttonSpeedEntry;
	private JTextField field_A, field_Am, field_Bp, field_B, field_Bm, field_Cp, field_C, field_Cm, field_Dp, field_D;
	private JRadioButton rdbCompleted, rdbIncomplete, skipFinal, takeFinal;
	private JCheckBox dropLowestBox;
	private boolean dropLowestBoolean;

	String speedEntryData;

	private ArrayList<Double> arrayHW, arrayLabs, arrayMidterms;
	private double courseGrade;


	public static void main(String[] args) {
		new CS429GUIGradeCalc();
	}

	public CS429GUIGradeCalc() {
		speedEntryData="HW: \nMidterm: \nLab: \nFinal: \n";
		this.setSize(new Dimension(580, 400));
		this.setTitle("GUI Grades Calculator");
		createView();
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
	}

	private void createView() {
		initialisePanels();
		setPanelLayout();
		gradeWeights();
		initialiseLabels();
		initialiseFields();
		gradeSection();
		selectorSection();
		gradeCutoffSetup();
		buttonPanelSetup();
		displayPanel.add(labelResult);
		panelsAssembly();
	}

	private void initialisePanels() {
		mainPanel = new JPanel();
		weightPanel = new JPanel();
		HWPanel = new JPanel();
		ExamPanel = new JPanel();
		ExamPanelLower = new JPanel();
		ExamSubPanel1 = new JPanel();
		ExamSubPanel2 = new JPanel();

		LabPanel = new JPanel();
		FinalsPanel = new JPanel();
		selectorsPanel = new JPanel();
		buttonPanel = new JPanel();
		displayPanel = new JPanel();
	}

	private void setPanelLayout() {
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		weightPanel.setLayout(new GridLayout(2, 4, 10, 0));
		HWPanel.setLayout(new GridLayout(2, 1, 0, 0));
		ExamPanel.setLayout(new GridLayout(2, 1, 0, 0));

		LabPanel.setLayout(new GridLayout(2, 1, 0, 0));
		FinalsPanel.setLayout(new GridLayout(2, 1, 0, 0));
		buttonPanel.setLayout(new GridLayout(1, 2, 10, 0));
		displayPanel.setLayout(new GridLayout(2, 1, 0, 0));
	}

	private void gradeWeights() {
		JLabel labelHWWeight = new JLabel("HW Weight");
		JLabel labelExamWeight = new JLabel("Exam Weight");
		JLabel labelLabWeight = new JLabel("Lab Weight");
		JLabel labelFinalsWeight = new JLabel("Final Exam");
		fieldHWWeight = new JTextField();
		fieldExamWeight = new JTextField();
		fieldLabWeight = new JTextField();
		fieldFinalWeight = new JTextField();
		fieldHWWeight.setText(HomeworkWeight);
		fieldExamWeight.setText(MidtermsWeight);
		fieldLabWeight.setText(LabWeight);
		fieldFinalWeight.setText(FinalExamWeight);
		weightPanel.add(labelHWWeight);
		weightPanel.add(labelExamWeight);
		weightPanel.add(labelLabWeight);
		weightPanel.add(labelFinalsWeight);
		weightPanel.add(fieldHWWeight);
		weightPanel.add(fieldExamWeight);
		weightPanel.add(fieldLabWeight);
		weightPanel.add(fieldFinalWeight);
	}

	private void gradeSection() {
		HWPanel.add(labelHW);
		HWPanel.add(fieldHW);
		ExamPanel.add(labelExam);
		dropLowestBox = new JCheckBox();
		ExamSubPanel1.setLayout(new GridLayout(1, 1, 0, 0));
		ExamSubPanel1.add(fieldExam);
		ExamSubPanel2.add(dropLowestBox);
		JLabel dropLabel = new JLabel("Drop Lowest");
		ExamSubPanel2.add(dropLabel);
		ExamSubPanel1.setPreferredSize(new Dimension(420, 20));
		ExamPanelLower.add(ExamSubPanel1);
		ExamPanelLower.add(dropLowestBox);
		ExamPanelLower.add(dropLabel);
		ExamPanel.add(ExamPanelLower);
		LabPanel.add(labelLabs);
		LabPanel.add(fieldLabs);
		FinalsPanel.add(labelFinalExam);
		FinalsPanel.add(fieldFinalExam);
	}

	private void selectorSection() {
		JPanel courseEvalSelector = new JPanel();
		JPanel skipFinalSelector = new JPanel();
		JPanel precisionSelector = new JPanel();
		labelCourseEval = new JLabel("Course Eval: ");
		rdbCompleted = new JRadioButton("Yes");
		rdbIncomplete = new JRadioButton("No");
		ButtonGroup bonusGroup = new ButtonGroup();
		bonusGroup.add(rdbCompleted);
		bonusGroup.add(rdbIncomplete);
		courseEvalSelector.add(labelCourseEval);
		courseEvalSelector.add(rdbCompleted);
		courseEvalSelector.add(rdbIncomplete);
		rdbIncomplete.setSelected(true);
		skip = new JLabel("Skip Final: ");
		skipFinal = new JRadioButton("Yes");
		takeFinal = new JRadioButton("No");
		ButtonGroup finalGroup = new ButtonGroup();
		finalGroup.add(skipFinal);
		finalGroup.add(takeFinal);
		skipFinalSelector.add(skip);
		skipFinalSelector.add(skipFinal);
		skipFinalSelector.add(takeFinal);
		labelPrecision = new JLabel("Precision: ");
		fieldPrecision = new JTextField();
		fieldPrecision.setText("3");
		fieldPrecision.setColumns(2);
		fieldPrecision.addFocusListener(new FocusListener() {
			String savedContent=fieldPrecision.getText();
			public void focusGained(FocusEvent arg0) {
				fieldPrecision.setText("");
			}
			public void focusLost(FocusEvent arg0) {
				if (!fieldPrecision.getText().equals(savedContent))
					savedContent = fieldPrecision.getText();
				fieldPrecision.setText(savedContent);
			}
		});
		precisionSelector.add(labelPrecision);
		precisionSelector.add(fieldPrecision);
		selectorsPanel.setLayout(new BoxLayout(selectorsPanel, BoxLayout.LINE_AXIS));
		selectorsPanel.add(courseEvalSelector);
		selectorsPanel.add(skipFinalSelector);
		selectorsPanel.add(precisionSelector);
		takeFinal.setSelected(true);
	}

	private void gradeCutoffSetup() {
		gradeCutoffPanel = new JPanel();
		JLabel label_A, label_Am, label_Bp, label_B, label_Bm, label_Cp, label_C, label_Cm, label_Dp, label_D;
		field_A = new JTextField("93"); 	field_A.setColumns(2);		label_A = new JLabel("A:");
		field_Am = new JTextField("90");	field_Am.setColumns(2);		label_Am = new JLabel("A-:");
		field_Bp = new JTextField("87"); 	field_Bp.setColumns(2);		label_Bp = new JLabel("B+:");
		field_B = new JTextField("83");		field_B.setColumns(2);		label_B = new JLabel("B:");
		field_Bm = new JTextField("80");	field_Bm.setColumns(2);		label_Bm = new JLabel("B-:");
		field_Cp = new JTextField("77");	field_Cp.setColumns(2);		label_Cp = new JLabel("C+:");
		field_C = new JTextField("73"); 	field_C.setColumns(2);		label_C = new JLabel("C:");
		field_Cm = new JTextField("70");	field_Cm.setColumns(2);		label_Cm = new JLabel("C-:");
		field_Dp = new JTextField("65");	field_Dp.setColumns(2);		label_Dp = new JLabel("D+:");
		field_D = new JTextField("60");		field_D.setColumns(2);		label_D = new JLabel("D:");
		gradeCutoffPanel.add(label_A);
		gradeCutoffPanel.add(field_A);
		gradeCutoffPanel.add(label_Am);
		gradeCutoffPanel.add(field_Am);
		gradeCutoffPanel.add(label_Bp);
		gradeCutoffPanel.add(field_Bp);
		gradeCutoffPanel.add(label_B);
		gradeCutoffPanel.add(field_B);
		gradeCutoffPanel.add(label_Bm);
		gradeCutoffPanel.add(field_Bm);
		gradeCutoffPanel.add(label_Cp);
		gradeCutoffPanel.add(field_Cp);
		gradeCutoffPanel.add(label_C);
		gradeCutoffPanel.add(field_C);
		gradeCutoffPanel.add(label_Cm);
		gradeCutoffPanel.add(field_Cm);
		gradeCutoffPanel.add(label_Dp);
		gradeCutoffPanel.add(field_Dp);
		gradeCutoffPanel.add(label_D);
		gradeCutoffPanel.add(field_D);
	}

	private void buttonPanelSetup() {
		buttonSpeedEntry = new JButton("Speed Entry");
		buttonSpeedEntry.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				speedEntry();
			}
		});
		buttonSubmit = new JButton();
		buttonSubmit.setText("Calculate");
		buttonSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				calculate();
			}
		});
		fractionConverter = new JButton("Fraction Convert Tool");
		fractionConverter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				fractionHelperWindow();
			}
		});
		buttonPanel.add(buttonSpeedEntry);
		buttonPanel.add(buttonSubmit);
		buttonPanel.add(fractionConverter);
	}

	private void panelsAssembly() {
		mainPanel.add(weightPanel);
		mainPanel.add(HWPanel);
		mainPanel.add(ExamPanel);
		mainPanel.add(LabPanel);
		mainPanel.add(FinalsPanel);
		mainPanel.add(selectorsPanel);
		mainPanel.add(gradeCutoffPanel);
		mainPanel.add(buttonPanel);
		mainPanel.add(displayPanel);
		this.getContentPane().add(mainPanel);
	}

	private void fractionHelperWindow() {
		JFrame fractionFrame = new JFrame("Convert Fraction Grades");
		JTextField helperDisplay = new JTextField("Press \"Convert\"");
		helperDisplay.setEditable(false);
		JLabel helperSlash = new JLabel(" / ");
		fractionFrame.setResizable(true);
		fractionFrame.setSize(200, 150);
		JPanel helperMain = new JPanel();
		JPanel helperFields = new JPanel();
		helperMain.setLayout(new GridLayout(3, 1, 0, 0));
		JTextField numerator = new JTextField();
		JTextField denominator = new JTextField();
		numerator.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent arg0) {
				numerator.setText("");
			}
			public void focusLost(FocusEvent arg0) {
			}
		});
		denominator.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent arg0) {
				denominator.setText("");
			}
			public void focusLost(FocusEvent arg0) {
			}
		});
		numerator.setColumns(6);
		denominator.setColumns(6);
		helperFields.add(numerator);
		helperFields.add(helperSlash);
		helperFields.add(denominator);
		helperMain.add(helperFields);
		JButton convert = new JButton("Convert");
		convert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (fieldIsNumeric(numerator) && fieldIsNumeric(denominator)) {
					helperDisplay.setText(fieldToDouble(numerator)*100.0/fieldToDouble(denominator)+"");
				}
				else {
					helperDisplay.setText("Invalid Input");
				}
			}
		});
		helperMain.add(convert);
		helperMain.add(helperDisplay);
		fractionFrame.setLocation(this.getX()+this.getWidth()+10, this.getY()-5);
		fractionFrame.getContentPane().add(helperMain);
		fractionFrame.setVisible(true);
	}

	private void initialiseLabels() {
		labelLabs = new JLabel();
		labelHW = new JLabel();
		labelExam = new JLabel();
		labelFinalExam =  new JLabel();
		labelResult = new JLabel();
		labelLabs.setText("Lab Grades: ");
		labelHW.setText("Homework Grades: ");
		labelExam.setText("Midterm Grades: ");
		labelFinalExam.setText("Final Exam: ");
		labelResult.setText("Click \"Calculate\"");
	}

	private void initialiseFields() {
		String initialLabText = "Enter lab grades (out of 100), seperated by a space";
		String initialHWText= "Enter HW grades (out of 100), seperated by a space. Ex: \"91.85 90 80 0 100\"";
		String initialExamText = "Enter midterm grades (out of 100), seperated by a space";
		String initialFinalText = "Enter final exam (actual or expected) grade (out of 100)";
		fieldLabs = new JTextField(initialLabText);
		fieldHW = new JTextField(initialHWText);
		fieldExam = new JTextField(initialExamText);
		fieldFinalExam = new JTextField(initialFinalText);
		setFieldFocus(initialLabText, initialHWText, initialExamText, initialFinalText);
	}

	// Make sure letter grade ranges make sense, ex: make sure C < A, and all are numbers
	private boolean letterRangeChecker() {
		if (fieldToDouble(field_A) < fieldToDouble(field_Am) ||
				fieldToDouble(field_A) <= fieldToDouble(field_Am) ||
				fieldToDouble(field_Am) <= fieldToDouble(field_Bp) ||
				fieldToDouble(field_Bp) <= fieldToDouble(field_B) ||
				fieldToDouble(field_B) <= fieldToDouble(field_Bm) ||
				fieldToDouble(field_Bm) <= fieldToDouble(field_Cp) ||
				fieldToDouble(field_Cp) <= fieldToDouble(field_C) ||
				fieldToDouble(field_C) <= fieldToDouble(field_Cm) ||
				fieldToDouble(field_Cm) <= fieldToDouble(field_Dp) ||
				fieldToDouble(field_Dp) <= fieldToDouble(field_D) ||
				!fieldIsInt(field_A) || !fieldIsInt(field_Am) || !fieldIsInt(field_Bp) ||
				!fieldIsInt(field_B) || !fieldIsInt(field_Bm) || !fieldIsInt(field_Cp) ||
				!fieldIsInt(field_C) || !fieldIsInt(field_Cm) || !fieldIsInt(field_Dp) ||
				!fieldIsInt(field_D))
			return false;
		else
			return true;
	}

	private void setFieldFocus(String lab, String hw, String exam, String finExam) {
		fieldLabs.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent arg0) {
				if (fieldLabs.getText().equals(lab))
					fieldLabs.setText("");
			}
			public void focusLost(FocusEvent arg0) {
				if (fieldLabs.getText().equals(""))
					fieldLabs.setText(lab);
			}});
		fieldHW.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent arg0) {
				if (fieldHW.getText().equals(hw))
					fieldHW.setText("");
			}
			public void focusLost(FocusEvent arg0) {
				if (fieldHW.getText().equals(""))
					fieldHW.setText(hw);
			}});
		fieldExam.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent arg0) {
				if (fieldExam.getText().equals(exam))
					fieldExam.setText("");
			}
			public void focusLost(FocusEvent arg0) {
				if (fieldExam.getText().equals(""))
					fieldExam.setText(exam);
			}});
		fieldFinalExam.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent arg0) {
				if (fieldFinalExam.getText().equals(finExam))
					fieldFinalExam.setText("");
			}
			public void focusLost(FocusEvent arg0) {
				if (fieldFinalExam.getText().equals(""))
					fieldFinalExam.setText(finExam);
			}});
	}

	private double roundtoPrecision(double value, double power10Precision) {
		return (Math.round(value*power10Precision)*1.0)/power10Precision;
	}

	private void calculate() {
		String letterGrade="";
		if (!fieldIsInt(fieldPrecision))
			labelResult.setText("Precision must be an integer");
		else if (!letterRangeChecker()) {
			labelResult.setText("LetterGrade Values Incorrect");
			letterGrade = "error";
		}
		else {
			if (fieldIsNumeric(fieldHW) && fieldIsNumeric(fieldExam) &&
					fieldIsNumeric(fieldFinalExam) && fieldIsNumeric(fieldLabs) && fieldIsNumeric(fieldHWWeight)
					 && fieldIsNumeric(fieldExamWeight) && fieldIsNumeric(fieldFinalWeight) && fieldIsNumeric(fieldLabWeight)) {
				arrayHW = new ArrayList<Double>();
				arrayLabs = new ArrayList<Double>();
				arrayMidterms = new ArrayList<Double>();
				makeArray(fieldHW, arrayHW);
				makeArray(fieldExam, arrayMidterms);
				makeArray(fieldLabs, arrayLabs);
				long precision = Math.round(fieldToDouble(fieldPrecision));
				dropLowestBoolean = dropLowestBox.isSelected();
				double power = Math.pow(10, precision);
				if (debug) System.out.println();
				double hwGrade = findAverage(arrayHW)*fieldToDouble(fieldHWWeight);
				if (debug) System.out.println("HW: "+roundtoPrecision(hwGrade/fieldToDouble(fieldHWWeight), power));
				double labGrade = findAverage(arrayLabs)*fieldToDouble(fieldLabWeight);
				if (debug) System.out.println("Lab: "+roundtoPrecision(labGrade/fieldToDouble(fieldLabWeight), power));
				double evalBonus = 0;
				if (rdbCompleted.isSelected())
					evalBonus += Course_Eval_Bonus_on_Final;
				if (debug) System.out.println("Bonus: "+evalBonus);
				double finalExamGrade = fieldToDouble(fieldFinalExam);
				if (skipFinal.isSelected())
					finalExamGrade = findAverage(arrayMidterms);
				if (debug) System.out.println("Final: "+ roundtoPrecision(finalExamGrade, power));
				finalExamGrade = (finalExamGrade+evalBonus)*fieldToDouble(fieldFinalWeight);
				double midterms = findAverage(arrayMidterms);
				if (dropLowestBoolean) {
					midterms = dropLowestGrade(arrayMidterms);//*fieldToDouble(fieldExamWeight);
				}
				if (debug) System.out.println("Midterm: "+roundtoPrecision(midterms, power));
				courseGrade = roundtoPrecision(hwGrade + labGrade + finalExamGrade + midterms*fieldToDouble(fieldExamWeight), power);
				if (debug) System.out.println("Course Grade: "+courseGrade+"\n");
				if (!letterGrade.equals("error")) letterGrade = getLetterGrade(courseGrade);
				if (letterGrade.equals("error"))
					labelResult.setText("Grade cutoff invalid");
				else if (midterms<0)
					labelResult.setText("You are missing some Midterm grades.");
				else if (fieldToDouble(fieldHWWeight)+fieldToDouble(fieldLabWeight)+
						fieldToDouble(fieldExamWeight)+fieldToDouble(fieldFinalWeight)!=1.0)
					labelResult.setText("Error. Grade Weights don't add up to 100%");
				else {
					labelResult.setText("Your course grade is "+courseGrade+"    Letter Grade: "+letterGrade);
				}
			}
			else {
				labelResult.setText("Invalid Input. Try again");
			}
		}

	}

	private double dropLowestGrade(ArrayList<Double> array) {
		double result = 0;
		if (array.size()<=1) {
			return -1000;
		}
		double[] sortedArray = new double[array.size()];
		for (int i=0; i<array.size(); i++) {
			sortedArray[i] = array.get(i);
		}
		Arrays.sort(sortedArray);
		for (int j=sortedArray.length-1; j>0; j--) {
			result += sortedArray[j];
		}

		return result/(sortedArray.length-1);
	}

	private String getLetterGrade(double grade) {
		if (fieldIsNumeric(field_D)&&fieldIsNumeric(field_Dp)&&fieldIsNumeric(field_Cm)&&
				fieldIsNumeric(field_C)&&fieldIsNumeric(field_Cp)&&fieldIsNumeric(field_Bm)&&fieldIsNumeric(field_B)&&fieldIsNumeric(field_Bp)&&
				fieldIsNumeric(field_Am)&&fieldIsNumeric(field_A)) {
			if (grade<fieldToDouble(field_D))
				return "F";
			else if (grade<fieldToDouble(field_Dp))
				return "D";
			else if (grade<fieldToDouble(field_Cm))
				return "D+";
			else if (grade<fieldToDouble(field_C))
				return "C-";
			else if (grade<fieldToDouble(field_Cp))
				return "C";
			else if (grade<fieldToDouble(field_Bm))
				return "C+";
			else if (grade<fieldToDouble(field_B))
				return "B-";
			else if (grade<fieldToDouble(field_Bp))
				return "B";
			else if (grade<fieldToDouble(field_Am))
				return "B+";
			else if (grade<fieldToDouble(field_A))
				return "A-";
			else {
				return "A";
			}
		}
		else {
			return "error";
		}
	}

	private double findAverage(ArrayList<Double> array) {
		double result=0;
		for (int index=0; index<array.size(); index++) {
			result += array.get(index);
		}
		return result/array.size();
	}

	private boolean fieldIsNumeric(JTextField textField) {
		String fieldText = textField.getText();
		if (fieldText.length()==0)
			return false;
		int letterInspectAscii;
		for (int character = 0; character<fieldText.length(); character++) {
			letterInspectAscii = (int) fieldText.charAt(character);
			if (letterInspectAscii!=32 && letterInspectAscii!=46 && (letterInspectAscii<48 || letterInspectAscii>57)) {
				return false;
			}
		}
		return true;
	}

	private boolean fieldIsInt(JTextField textField) {
		String fieldText = textField.getText();
		if (fieldText.length()==0)
			return false;
		int letterInspectAscii;
		for (int character = 0; character<fieldText.length(); character++) {
			letterInspectAscii = (int) fieldText.charAt(character);
			if (letterInspectAscii<48 || letterInspectAscii>57) {
				return false;
			}
		}
		return true;
	}


	private void makeArray(JTextField field, ArrayList<Double> array) {
		Scanner sc = new Scanner(field.getText());
		while (sc.hasNext()) {
			array.add(sc.nextDouble());
		}
		sc.close();
	}

	private double fieldToDouble(JTextField field) {
		Scanner sc = new Scanner(field.getText());
		double result = sc.nextDouble();
		sc.close();
		return result;
	}

	private void speedEntry() {
		JFrame speedEntryFrame = new JFrame("Speed Entry Mode");
		JPanel speedMainPanel = new JPanel();
		speedEntryFrame.setLocation(this.getX(), this.getY());
		speedEntryFrame.setSize(new Dimension(600, 200));
		JTextArea speedEntryArea = new JTextArea();
		speedEntryArea.setRows(8);
		speedEntryArea.setColumns(50);
		String speedEntryInstructions = "For each line, type either \"HW: \" or \"Midterm: \" or \"Lab: \" or \"Final: \",\n then followed by grades for the corresponding category of grades. \nPress \"Submit\" when finished.";
		speedEntryArea.setText(speedEntryInstructions);
		speedEntryArea.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent arg0) {
				speedEntryArea.setText(speedEntryData);
			}
			public void focusLost(FocusEvent arg0) {
				speedEntryData = speedEntryArea.getText();
			}
		});
		JButton showInstructions = new JButton("Help");
		showInstructions.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				speedEntryArea.setText(speedEntryInstructions);
			}
		});
		JButton showExample = new JButton("Example");
		showExample.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				speedEntryArea.setText("HW: 90 90 100 100 100 80 80 90 100 100 80 100\nMidterm: 91.66 83.75 94.59\nLab: 92.08 99 100 100 95 94.5\nFinal: 90");
			}
		});
		JButton submitSpeedEntry = new JButton("Submit");
		submitSpeedEntry.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Scanner speedEntryScanner = new Scanner(speedEntryData);
				while(speedEntryScanner.hasNextLine()) {
					String nextLine = speedEntryScanner.nextLine();
					Scanner lineScanner = new Scanner(nextLine);
					String fieldName = lineScanner.next();
					JTextField fieldtoEdit;
					if (fieldName.equals("HW:"))
						fieldtoEdit = fieldHW;
					else if (fieldName.equals("Midterm:"))
						fieldtoEdit = fieldExam;
					else if (fieldName.equals("Lab:"))
						fieldtoEdit = fieldLabs;
					else {
						fieldtoEdit = fieldFinalExam;
					}
					String lineData = "";
					while (lineScanner.hasNext()) {
						lineData+=lineScanner.next()+" ";
					}
					fieldtoEdit.setText(lineData);
					lineScanner.close();
				}
				speedEntryScanner.close();
				speedEntryFrame.setVisible(false);
			}
		});
		JButton clearSpeedEntry = new JButton("Clear");
		clearSpeedEntry.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				speedEntryData="HW: \nMidterm: \nLab: \nFinal: \n";
				speedEntryArea.setText(speedEntryData);
			}
		});
		speedMainPanel.add(speedEntryArea);
		speedMainPanel.add(showInstructions);
		speedMainPanel.add(showExample);
		speedMainPanel.add(submitSpeedEntry);
		speedMainPanel.add(clearSpeedEntry);
		speedEntryFrame.getContentPane().add(speedMainPanel);
		speedEntryFrame.setResizable(false);
		speedEntryFrame.setVisible(true);
	}

}