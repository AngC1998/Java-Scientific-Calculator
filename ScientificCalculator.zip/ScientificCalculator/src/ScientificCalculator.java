/**
 * @(#)ScientificCalculator.java
 *
 * ScientificCalculator application
 *
 * @author
 * @version 1.00 2018/6/3
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.Math;
import java.text.AttributedString;
import java.util.*;

public class ScientificCalculator extends JFrame{

	private static JFrame calculator;
	private static JTextArea screen;
	private static JButton b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, bOn, bShift, bClear,
	bAns, bPoint, bSign, bDivide, bMultiply, bSub, bAdd, bSin, bCos, bTan, bMode,
	bInverse, bLog, bLn, bPi, bPower, bRoot, bSquare, bLeft, bRight, bEE, bEnter;
	private static Stack operationStack;
	private static Stack numberStack;
	private static boolean calculatorOn, secondMode, radianMode, answered, containsTrig, containsOp, oneOp;
	private static double answer;

	public ScientificCalculator() {
		calculator = new JFrame();
		screen = new JTextArea();
		screen.setBounds(5, 5, 375, 90);
		calculator.add(screen);
		operationStack = new Stack();
		numberStack = new Stack();
		addNumbers();
		addOperators();
		addSpecial();
		addFunctions();
		addTrig();
		calculatorOn = true;
		secondMode = false;
		radianMode = true;
		answered = false;
		oneOp = false;
		containsOp = false;
		answer = 0;
		calculator.setSize(400, 500);
		calculator.setLayout(null);
		calculator.setVisible(true);
	}
	public static void clearScreen() {
		if(answered) {
			answered = !answered;
			screen.setText(null);
		}
	}
	public static double doOperation(double numOne, double numTwo, char op) {
		double answer = 0.0;
		if(op == '+') {
			answer = numOne + numTwo;
		}
		else if(op == '-') {
			answer = numOne - numTwo;
		}
		else if(op == 'x') {
			answer = numOne * numTwo;
		}
		else if(op == '/') {
			answer = numOne / numTwo;
		}
		else {
			answer = Math.pow(numOne, numTwo);
		}
		return answer;
	}
	public static void addNumbers() {
		//0 Button
		b0 = new JButton("0");
		b0.setBounds(80, 400, 70, 40);
		calculator.add(b0);
		b0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("0");
			}
		});
		//1 Button
		b1 = new JButton("1");
		b1.setBounds(80, 350, 70, 40);
		calculator.add(b1);
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("1");
			}
		});
		//2 Button
		b2 = new JButton("2");
		b2.setBounds(155, 350, 70, 40);
		calculator.add(b2);
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("2");
			}
		});
		//3 Button
		b3 = new JButton("3");
		b3.setBounds(230, 350, 70, 40);
		calculator.add(b3);
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("3");
			}
		});
		//4 Button
		b4 = new JButton("4");
		b4.setBounds(80, 300, 70, 40);
		calculator.add(b4);
		b4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("4");
			}
		});
		//5 Button
		b5 = new JButton("5");
		b5.setBounds(155, 300, 70, 40);
		calculator.add(b5);
		b5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("5");
			}
		});
		//6 Button
		b6 = new JButton("6");
		b6.setBounds(230, 300, 70, 40);
		calculator.add(b6);
		b6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("6");
			}
		});
		//7 Button
		b7 = new JButton("7");
		b7.setBounds(80, 250, 70, 40);
		calculator.add(b7);
		b7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("7");
			}
		});
		//8 Button
		b8 = new JButton("8");
		b8.setBounds(155, 250, 70, 40);
		calculator.add(b8);
		b8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("8");
			}
		});
		//9 Button
		b9 = new JButton("9");
		b9.setBounds(230, 250, 70, 40);
		calculator.add(b9);
		b9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("9");
			}
		});
	}
	public static void addOperators() {
		//Power or Log Button
		bPower = new JButton("^");
		bPower.setBounds(305, 150, 70, 40);
		calculator.add(bPower);
		bPower.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("^");
				if(!oneOp && !containsOp) {
					oneOp = true;
					containsOp = true;
				}
				else if(oneOp && containsOp) {
					oneOp = false;
				}
			}
		});
		//Divide Button
		bDivide = new JButton("/");
		bDivide.setBounds(305, 200, 70, 40);
		calculator.add(bDivide);
		bDivide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("/");
				if(!oneOp && !containsOp) {
					oneOp = true;
					containsOp = true;
				}
				else if(oneOp && containsOp) {
					oneOp = false;
				}
			}
		});
		//Multiply Button
		bMultiply = new JButton("x");
		bMultiply.setBounds(305, 250, 70, 40);
		calculator.add(bMultiply);
		bMultiply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("x");
				if(!oneOp && !containsOp) {
					oneOp = true;
					containsOp = true;
				}
				else if(oneOp && containsOp) {
					oneOp = false;
				}
			}
		});
		//Subtract Button
		bSub = new JButton("-");
		bSub.setBounds(305, 300, 70, 40);
		calculator.add(bSub);
		bSub.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("-");
				if(!oneOp && !containsOp) {
					oneOp = true;
					containsOp = true;
				}
				else if(oneOp && containsOp) {
					oneOp = false;
				}
			}
		});
		//Add Button
		bAdd = new JButton("+");
		bAdd.setBounds(305, 350, 70, 40);
		calculator.add(bAdd);
		bAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append(" + ");
				if(!oneOp && !containsOp) {
					oneOp = true;
					containsOp = true;
				}
				else if(oneOp && containsOp) {
					oneOp = false;
				}
			}
		});
		//Equals/Result Button
		bEnter = new JButton("=");
		bEnter.setBounds(305, 400, 70, 40);
		calculator.add(bEnter);
		bEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String equationLine = screen.getText();
				//Trig
				if(containsTrig) {
					if(radianMode) {

					}
					else {

					}
				}
				//PEDMAS
				if(oneOp) {
					if(equationLine.contains("+")) {
						System.out.println(equationLine.indexOf('+'));
						String[] numStr = equationLine.split(" + ");
						System.out.println(numStr[0]+","+numStr[1]);
						double numOne = Double.parseDouble(numStr[0]);
						double numTwo = Double.parseDouble(numStr[1]);
						System.out.println(numOne+" "+numTwo);
						answer = doOperation(numOne, numTwo, '+');
						System.out.println(answer);
					}
					else if(equationLine.contains("-")) {
						System.out.println(equationLine.indexOf('-'));
						String[] numStr = equationLine.split("-");
						double numOne = Double.parseDouble(numStr[0]);
						double numTwo = Double.parseDouble(numStr[1]);
						answer = doOperation(numOne, numTwo, '-');
						System.out.println(answer);
					}
					else if(equationLine.contains("x")) {
						System.out.println(equationLine.indexOf('x'));
						String[] numStr = equationLine.split("x");
						double numOne = Double.parseDouble(numStr[0]);
						double numTwo = Double.parseDouble(numStr[1]);
						answer = doOperation(numOne, numTwo, 'x');
						System.out.println(answer);
					}
					else if(equationLine.contains("/")) {
						System.out.println(equationLine.indexOf('/'));
						String[] numStr = equationLine.split("/");
						double numOne = Double.parseDouble(numStr[0]);
						double numTwo = Double.parseDouble(numStr[1]);
						answer = doOperation(numOne, numTwo, '/');
						System.out.println(answer);
					}
					else {
						System.out.println(equationLine.indexOf('^'));
						String[] numStr = equationLine.split("^");
						double numOne = Double.parseDouble(numStr[0]);
						double numTwo = Double.parseDouble(numStr[1]);
						answer = doOperation(numOne, numTwo, '^');
						System.out.println(answer);
					}
					oneOp = !oneOp;
					containsOp = !containsOp;
				}
				screen.append("\n");
				screen.append("Ans: "+answer);
				screen.append("\n");
				answered = true;
			}
		});
	}
	public static void addSpecial() {
		//Shift Button
		bShift = new JButton("2nd");
		bShift.setBounds(5, 100, 70, 40);
		calculator.add(bShift);
		bShift.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(secondMode) {
					bSin.setText("sin");
					bCos.setText("cos");
					bTan.setText("tan");
					bLog.setText("log");
					bLn.setText("ln");
					bPi.setText("pi");
					bSquare.setText("x^2");
				}
				else {
					bSin.setText("asin");
					bCos.setText("acos");
					bTan.setText("atan");
					bLog.setText("10^x");
					bLn.setText("e^x");
					bPi.setText("e");
					bSquare.setText("sqrt");
				}
				secondMode = !secondMode;
			}
		});
		//Pi or e Button
		bPi = new JButton("pi");
		bPi.setBounds(230, 150, 70, 40);
		calculator.add(bPi);
		bPi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				if(!secondMode)
					screen.append(""+Math.PI);
				else
					screen.append(""+Math.E);
			}
		});
		//Left Parentheses Button
		bLeft = new JButton("(");
		bLeft.setBounds(155, 200, 70, 40);
		calculator.add(bLeft);
		bLeft.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("(");
			}
		});
		//Right Parentheses Button
		bRight = new JButton(")");
		bRight.setBounds(230, 200, 70, 40);
		calculator.add(bRight);
		bRight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append(")");
			}
		});
		//Answer Storage Button
		bAns = new JButton("Ans");
		bAns.setBounds(5, 250, 70, 40);
		calculator.add(bAns);
		bAns.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String ans = ""+answer;
				if(ans.substring(ans.length()-2, ans.length()).equals(".0"))
					ans = ans.substring(0, ans.length()-2);
				screen.append(""+ans);
			}
		});
		//Clear or All Clear Button
		bClear = new JButton("C");
		bClear.setBounds(5, 350, 70, 40);
		calculator.add(bClear);
		bClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				screen.setText(null);
			}
		});
		//Power Button
		bOn = new JButton("ON");
		bOn.setBounds(5, 400, 70, 40);
		calculator.add(bOn);
		bOn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				screen.setText(null);
			}
		});
		//Decimal Point Button
		bPoint = new JButton(".");
		bPoint.setBounds(155, 400, 70, 40);
		calculator.add(bPoint);
		bPoint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append(".");
			}
		});
		//Pos/Neg Sign Button
		bSign = new JButton("(-)");
		bSign.setBounds(230, 400, 70, 40);
		calculator.add(bSign);
	}
	public static void addFunctions() {
		//Inverse Button
		bInverse = new JButton("1/x");
		bInverse.setBounds(5, 150, 70, 40);
		calculator.add(bInverse);
		bInverse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("^-1");
			}
		});
		//Log10 or 10^x Button
		bLog = new JButton("log");
		bLog.setBounds(80, 150, 70, 40);
		calculator.add(bLog);
		bLog.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				if(!secondMode)
					screen.append("log(");
				else
					screen.append("10^(");
			}
		});
		//Ln/LogE or e^x Button
		bLn = new JButton("ln");
		bLn.setBounds(155, 150, 70, 40);
		calculator.add(bLn);
		bLn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				if(!secondMode)
					screen.append("ln(");
				else
					screen.append("e^(");
			}
		});
		//n-Root Button
		bRoot = new JButton("nrt");
		bRoot.setBounds(5, 200, 70, 40);
		calculator.add(bRoot);
		bRoot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				screen.append("rt(");
			}
		});
		//x^2 or Square Root Button
		bSquare = new JButton("x^2");
		bSquare.setBounds(80, 200, 70, 40);
		calculator.add(bSquare);
		bSquare.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				if(!secondMode)
					screen.append("^2");
				else
					screen.append("sqrt(");
			}
		});
		//Exponent (10^n) Button
		bEE = new JButton("EE");
		bEE.setBounds(5, 300, 70, 40);
		calculator.add(bEE);
	}
	public static void addTrig() {
		//Sine Button
		bSin = new JButton("sin");
		bSin.setBounds(80, 100, 70, 40);
		calculator.add(bSin);
		bSin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				if(!secondMode)
					screen.append("sin(");
				else
					screen.append("sin^-1(");
				containsTrig = true;
			}
		});
		//Cosine Button
		bCos = new JButton("cos");
		bCos.setBounds(155, 100, 70, 40);
		calculator.add(bCos);
		bCos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				if(!secondMode)
					screen.append("cos(");
				else
					screen.append("cos^-1(");
				containsTrig = true;
			}
		});
		//Tangent Button
		bTan = new JButton("tan");
		bTan.setBounds(230, 100, 70, 40);
		calculator.add(bTan);
		bTan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clearScreen();
				if(!secondMode)
					screen.append("tan(");
				else
					screen.append("cos^-1(");
				containsTrig = true;
			}
		});
		//Mode (Rad/Deg) Button
		bMode = new JButton("Rad");
		bMode.setBounds(305, 100, 70, 40);
		calculator.add(bMode);
		bMode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(bMode.getText().equals("Rad")) {
					bMode.setText("Deg");
					radianMode = false;
				}
				else {
					bMode.setText("Rad");
					radianMode = true;
				}
			}
		});
	}
    public static void main(String[] args) {
    	// TODO, add your application code
    	new ScientificCalculator();
    }
}
